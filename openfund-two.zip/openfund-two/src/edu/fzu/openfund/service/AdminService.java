package edu.fzu.openfund.service;

public interface AdminService {
	Boolean validate(String userName,String userpwd);
}
