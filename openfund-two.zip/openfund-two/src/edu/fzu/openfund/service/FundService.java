package edu.fzu.openfund.service;

import java.util.List;

public interface FundService {
	List getAllFunds();
}
