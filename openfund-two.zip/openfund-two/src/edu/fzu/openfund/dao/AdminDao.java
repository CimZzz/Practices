package edu.fzu.openfund.dao;

public interface AdminDao {
	Boolean validate(String username,String userpwd);
}
