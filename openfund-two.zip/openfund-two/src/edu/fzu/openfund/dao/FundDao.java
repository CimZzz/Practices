package edu.fzu.openfund.dao;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

public interface FundDao {
	List findAllFunds();
	
}
